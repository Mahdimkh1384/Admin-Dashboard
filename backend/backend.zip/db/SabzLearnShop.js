const mysql = require("mysql");

const SabzlearnShopDB = mysql.createConnection({
  host: "localhost",
  user: "sajyir_test",
  password: "D}uM[P}6VlXQ",
  database: "sajyir_test",
});

module.exports = SabzlearnShopDB;
